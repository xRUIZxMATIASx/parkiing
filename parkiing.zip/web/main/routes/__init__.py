from main.routes.login import login
from main.routes.home import home
from main.routes.users import users
from main.routes.config import config