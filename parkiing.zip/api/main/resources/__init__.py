from .Parking import Parking as ParkingResource
from .User import User as UserResource
from .GenerateQR import GenerateQR as GenerateQRResource
#from .User import Users as UsersResource
